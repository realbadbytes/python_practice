=========================
Example Package
=========================

License: MIT

Documentation: https://example.com

Usage
-----

``sample --help``
