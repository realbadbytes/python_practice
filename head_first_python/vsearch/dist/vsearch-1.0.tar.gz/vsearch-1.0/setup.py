from setuptools import setup
setup(
    name = 'vsearch',
    version = '1.0',
    description = 'The Head First Python Search Tools',
    author = 'realbadbytes',
    author_email = 'test@noob.com',
    url = 'test.com',
    # The list of py files to include in the package
    py_modules = ['vsearch'])
